const express = require('express');
const router = express.Router();
const { executeQuery } = require('../config/database');
const { authenticateToken, requireRole } = require('../middleware/auth');

// Get admin dashboard statistics
router.get('/dashboard', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        // Get various statistics
        const [totalCustomers] = await executeQuery('SELECT COUNT(*) as count FROM customers');
        const [totalAccounts] = await executeQuery('SELECT COUNT(*) as count FROM accounts WHERE status = "active"');
        const [totalBalance] = await executeQuery('SELECT SUM(balance) as total FROM accounts WHERE status = "active"');
        const [totalTransactions] = await executeQuery('SELECT COUNT(*) as count FROM transactions WHERE DATE(created_at) = CURDATE()');

        const stats = {
            totalCustomers: totalCustomers[0].count,
            totalAccounts: totalAccounts[0].count,
            totalBalance: totalBalance[0].total || 0,
            todayTransactions: totalTransactions[0].count
        };

        res.json({
            success: true,
            data: stats
        });

    } catch (error) {
        console.error('Admin dashboard error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to retrieve dashboard data'
        });
    }
});

// Get all customers
router.get('/customers', authenticateToken, requireRole(['admin', 'employee']), async (req, res) => {
    try {
        const { page = 1, limit = 20 } = req.query;
        const offset = (page - 1) * limit;

        const customers = await executeQuery(
            `SELECT c.*, u.username, u.email, u.is_active
             FROM customers c
             JOIN users u ON c.user_id = u.id
             ORDER BY c.created_at DESC
             LIMIT ? OFFSET ?`,
            [parseInt(limit), parseInt(offset)]
        );

        res.json({
            success: true,
            data: customers
        });

    } catch (error) {
        console.error('Get customers error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to retrieve customers'
        });
    }
});

module.exports = router;