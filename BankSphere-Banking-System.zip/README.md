# 🏦 BankSphere - Modern Banking System

A comprehensive, secure full-stack bank management system built with Node.js, Express, MySQL, and vanilla JavaScript. Features complete banking functionality with role-based access control and 3 advanced features that showcase modern banking technology.

## ✨ Key Features

### 🏛️ Core Banking System
- **Complete User Management** - Registration, login, role-based access (Customer/Admin/Employee)
- **Account Management** - Multiple account types, real-time balances, transaction history
- **Money Transfers** - Secure deposits, withdrawals, and peer-to-peer transfers
- **Loan System** - Application, approval workflow, payment processing
- **Admin Dashboard** - Customer management, loan approvals, system oversight

### 🚀 Advanced Features
1. **💰 Cryptocurrency Trading** - Buy, sell, and manage Bitcoin, Ethereum, and other digital assets
2. **🛡️ AI Fraud Detection** - Real-time AI-powered fraud detection and prevention system
3. **🤖 AI Banking Assistant** - 24/7 intelligent chatbot for customer service and financial guidance

### 🔒 Enterprise Security
- JWT authentication with role-based access control
- SQL injection prevention and input sanitization
- Password hashing with bcrypt
- Rate limiting and audit logging
- Secure HTTP headers and CORS protection

## 🛠 Technology Stack

**Backend:** Node.js, Express.js, MySQL, JWT, bcrypt  
**Frontend:** HTML5, CSS3, JavaScript (ES6+), Bootstrap 5  
**Security:** Helmet.js, express-validator, express-rate-limit

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- MySQL (v8.0 or higher)
- npm package manager

### Installation

1. **Clone and Install**
   ```bash
   git clone <repository-url>
   cd banksphere-main
   npm install
   ```

2. **Database Setup**
   ```bash
   # Make sure MySQL is running
   # Update .env file with your MySQL credentials
   node init_database.js
   ```

3. **Start the Application**
   ```bash
   npm start
   ```

4. **Access the Application**
   - Open browser to `http://localhost:3000`
   - **Admin Login:** username=`admin`, password=`admin123`
   - **Customer Login:** username=`john_doe`, password=`password123`

## 🎯 User Interfaces

### 👤 Customer Dashboard (`/enhanced-dashboard.html`)
- Personal banking features
- Cryptocurrency trading interface
- AI assistant chat
- Security monitoring
- Account management and transfers

### 🛡️ Admin Dashboard (`/admin-dashboard.html`)
- Customer management
- Loan approval system
- SQL query interface
- System reports and analytics
- Transaction monitoring

## 🔧 Configuration

Update `.env` file with your settings:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=bank_management
JWT_SECRET=your_jwt_secret
PORT=3000
```

## 📁 Project Structure

```
banksphere-main/
├── config/          # Database configuration
├── middleware/      # Security and validation middleware
├── routes/          # API route handlers
├── public/          # Frontend files (HTML, CSS, JS)
├── database/        # Database schema and sample data
├── server.js        # Main application server
├── init_database.js # Database initialization script
└── package.json     # Dependencies and scripts
```

## 🎨 Features Showcase

### 💰 Cryptocurrency Trading
- Real-time market prices
- Buy/sell interface
- Portfolio tracking
- Wallet management

### 🛡️ AI Fraud Detection
- Real-time transaction monitoring
- Security score tracking
- Threat detection alerts
- Activity timeline

### 🤖 AI Banking Assistant
- Interactive chat interface
- Account inquiries
- Transaction help
- Financial guidance

## 🔒 Security Features

- **Authentication:** JWT tokens with role-based access
- **Data Protection:** SQL injection prevention, XSS protection
- **Input Validation:** Server-side validation and sanitization
- **Rate Limiting:** API endpoint protection
- **Audit Logging:** Complete activity tracking

## 📊 Default Accounts

| Role | Username | Password | Access |
|------|----------|----------|---------|
| Admin | admin | admin123 | Full system access |
| Customer | john_doe | password123 | Customer features |

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

---

**BankSphere** - Modern banking technology with enterprise security and advanced features.

## 📋 Prerequisites

- Node.js (v14 or higher)
- MySQL (v8.0 or higher)
- npm or yarn package manager

## 🚀 Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd bank-management-system
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Database Setup
```bash
# Create the database and tables
mysql -u root -p < database/schema.sql

# Insert sample data (optional)
mysql -u root -p < database/sample_data.sql
```

### 4. Environment Configuration
```bash
# Copy the example environment file
cp .env.example .env

# Edit the .env file with your configuration
nano .env
```

Required environment variables:
```env
# Database Configuration
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=bank_management

# JWT Configuration
JWT_SECRET=your_super_secret_jwt_key_here
JWT_EXPIRES_IN=24h

# Session Configuration
SESSION_SECRET=your_session_secret_here

# Server Configuration
PORT=3000
NODE_ENV=development

# Email Configuration (for password recovery)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password

# Security
BCRYPT_ROUNDS=12
```

### 5. Start the Application
```bash
# Development mode
npm run dev

# Production mode
npm start
```

The application will be available at `http://localhost:3000`

## 👥 Default User Accounts

### Admin Account
- **Username:** admin
- **Password:** admin123
- **Role:** Administrator

### Sample Customer Accounts
- **Username:** john_doe
- **Password:** password123
- **Role:** Customer

- **Username:** jane_smith
- **Password:** password123
- **Role:** Customer

### Employee Account
- **Username:** emp_manager
- **Password:** employee123
- **Role:** Employee

## 🔐 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new customer
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password

### Accounts
- `GET /api/accounts` - Get user accounts
- `GET /api/accounts/:id` - Get account details
- `POST /api/accounts` - Create new account (Employee/Admin)
- `PATCH /api/accounts/:id/status` - Update account status
- `GET /api/accounts/:id/transactions` - Get account transactions

### Transactions
- `POST /api/transactions/deposit` - Make deposit
- `POST /api/transactions/withdraw` - Make withdrawal
- `POST /api/transactions/transfer` - Transfer money
- `GET /api/transactions/history` - Get transaction history

### Loans
- `GET /api/loans` - Get user loans
- `POST /api/loans/apply` - Apply for loan
- `GET /api/loans/:id` - Get loan details
- `PATCH /api/loans/:id/status` - Approve/reject loan (Employee/Admin)
- `GET /api/loans/:id/payments` - Get payment schedule
- `POST /api/loans/:id/payments` - Make loan payment

### Profile
- `GET /api/profile` - Get user profile
- `PUT /api/profile` - Update profile
- `PUT /api/profile/password` - Change password
- `GET /api/profile/dashboard` - Get dashboard data
- `GET /api/profile/notifications` - Get notifications

### Admin
- `GET /api/admin/dashboard` - Get admin statistics
- `GET /api/admin/customers` - Get all customers
- `GET /api/admin/customers/:id` - Get customer details
- `PATCH /api/admin/customers/:id/status` - Update customer status
- `GET /api/admin/branches` - Get all branches
- `POST /api/admin/branches` - Create new branch
- `POST /api/admin/sql-query` - Execute SQL query
- `GET /api/admin/reports/:type` - Generate reports

## 🗄 Database Schema

### Core Tables
- **users** - User authentication and basic info
- **customers** - Customer profile information
- **employees** - Employee information
- **branches** - Bank branch details
- **account_types** - Account type definitions
- **accounts** - Customer accounts
- **transactions** - All financial transactions
- **loans** - Loan information
- **loan_payments** - Loan payment schedule
- **support_tickets** - Customer support tickets
- **audit_log** - Security and audit logging

### Key Relationships
- Users → Customers (1:1)
- Users → Employees (1:1)
- Customers → Accounts (1:N)
- Accounts → Transactions (1:N)
- Customers → Loans (1:N)
- Loans → Loan Payments (1:N)

## 🔒 Security Features

### Input Validation
- Server-side validation using express-validator
- Client-side real-time validation
- SQL injection prevention with prepared statements
- XSS protection through input sanitization

### Authentication & Authorization
- JWT-based stateless authentication
- Role-based access control
- Secure password hashing with bcrypt
- Rate limiting on sensitive endpoints

### Data Protection
- HTTPS enforcement in production
- Secure HTTP headers via Helmet.js
- CORS configuration
- Environment variable protection

### Audit & Monitoring
- Comprehensive audit logging
- Transaction monitoring
- Failed login attempt tracking
- Administrative action logging

## 📊 Admin SQL Interface

The system includes a secure SQL query interface for administrators:

### Allowed Operations
- `SELECT` - Data retrieval
- `INSERT` - Data insertion
- `UPDATE` - Data modification
- `DELETE` - Data removal
- `SHOW` - Database information
- `DESCRIBE` - Table structure
- `EXPLAIN` - Query execution plans

### Security Restrictions
- Dangerous operations blocked (DROP, TRUNCATE, ALTER, etc.)
- Query execution time limits
- Result set size limits
- Audit logging of all queries

### Example Queries
```sql
-- View all customers
SELECT * FROM customers LIMIT 10;

-- Check account balances
SELECT account_number, balance, status FROM accounts WHERE status = 'active';

-- Transaction summary
SELECT transaction_type, COUNT(*), SUM(amount) 
FROM transactions 
WHERE created_at >= CURDATE() 
GROUP BY transaction_type;

-- Update account status
UPDATE accounts SET status = 'active' WHERE id = 1;
```

## 🧪 Testing

### Manual Testing Guide

1. **User Registration**
   - Test with valid and invalid data
   - Verify email uniqueness
   - Check password strength requirements

2. **Authentication**
   - Test login with correct/incorrect credentials
   - Verify JWT token generation
   - Test logout functionality

3. **Account Operations**
   - Create different account types
   - Test balance updates
   - Verify minimum balance enforcement

4. **Transactions**
   - Test deposits and withdrawals
   - Verify transfer functionality
   - Check transaction limits

5. **Loan Processing**
   - Apply for different loan types
   - Test approval workflow
   - Verify payment processing

### API Testing with curl

```bash
# Register new user
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"Test123!","firstName":"Test","lastName":"User",...}'

# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"Test123!"}'

# Get accounts (with JWT token)
curl -X GET http://localhost:3000/api/accounts \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

## 🚀 Deployment

### Production Deployment

1. **Environment Setup**
   ```bash
   NODE_ENV=production
   PORT=80
   # Use strong secrets in production
   JWT_SECRET=your_production_jwt_secret
   SESSION_SECRET=your_production_session_secret
   ```

2. **Database Configuration**
   - Use connection pooling
   - Enable SSL connections
   - Regular backups
   - Performance monitoring

3. **Security Hardening**
   - Enable HTTPS with SSL certificates
   - Configure firewall rules
   - Set up intrusion detection
   - Regular security updates

4. **Performance Optimization**
   - Enable gzip compression
   - Use CDN for static assets
   - Database query optimization
   - Caching strategies

### Docker Deployment

```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## 📈 Performance Considerations

### Database Optimization
- Proper indexing on frequently queried columns
- Connection pooling for concurrent requests
- Query optimization and monitoring
- Regular database maintenance

### Application Performance
- Efficient error handling
- Memory leak prevention
- Asynchronous operations
- Response caching where appropriate

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue in the GitHub repository
- Check the documentation for common solutions
- Review the API endpoints and examples

## 🔄 Version History

- **v1.0.0** - Initial release with core banking features
- **v1.1.0** - Added loan management system
- **v1.2.0** - Enhanced security features and admin interface
- **v1.3.0** - Added SQL query interface and reporting

## 🎯 Future Enhancements

- Two-factor authentication
- Mobile app development
- Advanced reporting and analytics
- Integration with external payment systems
- Cryptocurrency support
- AI-powered fraud detection
- Real-time chat support
- Document management system